Folder Orientation

Filename explanation:
Filenames have the basic structure of 
scan[0-9]+ D[1-4] (Al|Pd) [2-4]00

>scan[0-9]+ gives the order the measurements were taken in. This should not be important since we are assuming the values obtained in these measurements are independent of each other.

>D[1-4] Tells us what device (group of memristors) the measurement was made on. Devices that have the same D[1-4] share the same Pd electrode.

>(Al|Pd) This tells us whether the measurement is made on the Al or Pd electrode

>[2-4]00 tells us the width of the electrode measured in micrometers