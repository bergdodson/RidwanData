Folder Orientation

Filename explanation:
Filenames have the basic structure of 
(Al|Pd) ([2-4]00)*

>(Al|Pd) This tells us whether the measurement is made on the Al or Pd electrode

>([2-4]00)* tells us the width of the electrode measured in micrometers. Pd electrodes are 200 um 